package model.webUser;
import dbUtils.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbMods {
    
          public static StringData logonFind(String email, String pw, DbConn dbc) {
            StringData foundData = new StringData();
            if ((email == null) || (pw == null)) {
                foundData.errorMsg = "Programmer error in model.webUser.DbMods.logonFind: email and pw must be both non-null.";
                return foundData;
            }
            try {
                String sql = "SELECT web_user_id, user_email, user_password, membership_fee, birthday, image, "
                        + "web_user.user_role_id, user_role_type "
                        + "FROM web_user, user_role "
                        + "WHERE web_user.user_role_id = user_role.user_role_id "
                        + "AND user_email = ? and user_password = ? ";
                PreparedStatement pStatement = dbc.getConn().prepareStatement(sql); 
                pStatement.setString(1, email); 
                pStatement.setString(2, pw);    
                ResultSet results = pStatement.executeQuery();    
                if (results.next()) {
                    return new StringData(results);
                } else {
                foundData.errorMsg = "Email and Password not found";
                return foundData;
                }
            } catch (Exception e) {
                foundData.errorMsg = "Exception in model.webUser.DbMods.logonFind(): " + e.getMessage();
                System.out.println("******" + foundData.errorMsg);
                return foundData;
            }
        }
 public static String delete(String userId, DbConn dbc) {

        if (userId == null) {
            return "Error in modelwebUser.DbMods.delete: cannot delete web_user record because 'userId' is null";
        }
        String result = "";
        try {

            String sql = "DELETE FROM web_user WHERE web_user_id = ?";

            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            pStatement.setString(1, userId);
            int numRowsDeleted = pStatement.executeUpdate();
            if (numRowsDeleted == 0) {
                result = "Record not deleted - there was no record with web_user_id " + userId;
            } else if (numRowsDeleted > 1) {
                result = "Programmer Error: > 1 record deleted. Did you forget the WHERE clause?";
            }
        } catch (Exception e) {
            result = "Exception thrown in model.webUser.DbMods.delete(): " + e.getMessage();
        }
        return result;
    }
  private static StringData validate(StringData inputData) {

        StringData errorMsgs = new StringData();

        /* Useful to copy field names from StringData as a reference
    public String webUserId = "";
    public String userEmail = "";
    public String userPassword = "";
    public String userPassword2 = "";
    public String birthday = "";
    public String membershipFee = "";
    public String userRoleId = "";   // Foreign Key
    public String userRoleType = ""; // getting it from joined user_role table.
         */
        // Validation
        errorMsgs.userEmail = ValidationUtils.stringValidationMsg(inputData.userEmail, 45, true);
        errorMsgs.userPassword = ValidationUtils.stringValidationMsg(inputData.userPassword, 45, true);

        if ((inputData.userPassword.compareTo(inputData.userPassword2)) != 0) {
            System.out.println("test");// case sensative comparison
            errorMsgs.userPassword2 = "Both passwords must match";
        }

        errorMsgs.birthday = ValidationUtils.dateValidationMsg(inputData.birthday, false);
        errorMsgs.membershipFee = ValidationUtils.decimalValidationMsg(inputData.membershipFee, false);
        errorMsgs.userRoleId = ValidationUtils.integerValidationMsg(inputData.userRoleId, true);

        return errorMsgs;
    } // validate 

    public static StringData insert(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        System.out.println("errorMsgs is " + errorMsgs);
        System.out.println("char count is " + errorMsgs.getCharacterCount());
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation

            /*
                  String sql = "SELECT web_user_id, user_email, user_password, membership_fee, birthday, "+
                    "web_user.user_role_id, user_role_type "+
                    "FROM web_user, user_role where web_user.user_role_id = user_role.user_role_id " + 
                    "ORDER BY web_user_id ";
             */
            // Start preparing SQL statement
            String sql = "INSERT INTO web_user (user_email, user_password, membership_fee, birthday, user_role_id) "
                    + "values (?,?,?,?,?)";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);

            // Encode string values into the prepared statement (wrapper class).
            pStatement.setString(1, inputData.userEmail); // string type is simple
            pStatement.setString(2, inputData.userPassword);
            pStatement.setBigDecimal(3, ValidationUtils.decimalConversion(inputData.membershipFee));
            pStatement.setDate(4, ValidationUtils.dateConversion(inputData.birthday));
            pStatement.setInt(5, ValidationUtils.integerConversion(inputData.userRoleId));

            // here the SQL statement is actually executed
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            errorMsgs.errorMsg = pStatement.getErrorMsg();
            if (errorMsgs.errorMsg.length() == 0) {
                if (numRows == 1) {
                    errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    errorMsgs.errorMsg = numRows + " records were inserted when exactly 1 was expected.";
                }
            } else if (errorMsgs.errorMsg.contains("foreign key")) {
                errorMsgs.errorMsg = "Invalid User Role Id";
            } else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                errorMsgs.errorMsg = "That email address is already taken";
            }

        } // customerId is not null and not empty string.
        return errorMsgs;
    } // insert
    
 
 
 

     
  
}