package model.userPost;
import dbUtils.*;
import java.sql.PreparedStatement;

public class DbMods {
    
     public static String delete(String userId, DbConn dbc) {

        if (userId == null) {
            return "Error in modelwebUser.DbMods.delete: cannot delete web_user record because 'postID' is null";
        }
        String result = "";
        try {

            String sql = "DELETE FROM user_post WHERE post_id = ?";

            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            pStatement.setString(1, userId);
            int numRowsDeleted = pStatement.executeUpdate();
            if (numRowsDeleted == 0) {
                result = "Record not deleted - there was no record with web_user_id " + userId;
            } else if (numRowsDeleted > 1) {
                result = "Programmer Error: > 1 record deleted. Did you forget the WHERE clause?";
            }
        } catch (Exception e) {
            result = "Exception thrown in model.userPost.DbMods.delete(): " + e.getMessage();
        }
        return result;
    }
     
     
     
     private static StringData validate(StringData inputData) {

        StringData errorMsgs = new StringData();

        /* Useful to copy field names from StringData as a reference
    public String postName = "";
    public String imageURL = "";
    public String description = "";
    public String yearsSkating = "";
    public String location = "";
    public String minutesShootingTrick = "";  
    public String webUserID = ""; //fk
         */
        // Validation
            errorMsgs.postName = ValidationUtils.stringValidationMsg(inputData.postName, 45, true);
            errorMsgs.imageURL = ValidationUtils.stringValidationMsg(inputData.imageURL, 250, true);
            errorMsgs.description = ValidationUtils.stringValidationMsg(inputData.description,240, false);
            errorMsgs.yearsSkating = ValidationUtils.integerValidationMsg(inputData.yearsSkating, false);
            errorMsgs.location = ValidationUtils.stringValidationMsg(inputData.location,45, false);
            errorMsgs.minutesShootingTrick = ValidationUtils.integerValidationMsg(inputData.minutesShootingTrick, false);
            errorMsgs.webUserID = ValidationUtils.integerValidationMsg(inputData.webUserID, true);

            

        return errorMsgs;
    } // validate 

    public static StringData insert(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { 
            
        String sql = "INSERT INTO user_post (post_name,image_url,description,years_skating,location, minutes_shooting_trick, web_user_id) "
                        + "values (?,?,?,?,?,?,?)";

            PrepStatement pStatement = new PrepStatement(dbc, sql);

                // Encode string values into the prepared statement (wrapper class).
                pStatement.setString(1, inputData.postName); // string type is simple
                pStatement.setString(2, inputData.imageURL);
                pStatement.setString(3, inputData.description); 
                pStatement.setInt(4, ValidationUtils.integerConversion(inputData.yearsSkating));
                pStatement.setString(5, inputData.location);
                pStatement.setInt(6, ValidationUtils.integerConversion(inputData.minutesShootingTrick));
                pStatement.setInt(7, ValidationUtils.integerConversion(inputData.webUserID));

                // here the SQL statement is actually executed
                int numRows = pStatement.executeUpdate();

                // This will return empty string if all went well, else all error messages.
                errorMsgs.errorMsg = pStatement.getErrorMsg();
                if (errorMsgs.errorMsg.length() == 0) {
                    if (numRows == 1) {
                        errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                    } else {
                        // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                        errorMsgs.errorMsg = numRows + " records were inserted when exactly 1 was expected.";
                    }
                } else if (errorMsgs.errorMsg.contains("foreign key")) {
                    errorMsgs.errorMsg = "Error you are not logged in!";
                } else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                    errorMsgs.errorMsg = "That Post Name is already taken";
                }

        } // customerId is not null and not empty string.
        return errorMsgs;
    } // insert
    

    
    
    
    
    
}
