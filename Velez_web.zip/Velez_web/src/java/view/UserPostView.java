
package view;

import dbUtils.DbConn;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.userPost.*;

public class UserPostView {

    public static StringDataList userPostAPI(DbConn dbc) {
        StringDataList sdl = new StringDataList();
        try {
            String sql = "SELECT post_id, post_name, image_url, description,years_skating,location,minutes_shooting_trick, "
                    + "user_post.web_user_id,user_email,user_password,birthday,membership_fee,user_role_id,image FROM user_post,web_user "
                    + "WHERE user_post.web_user_id = web_user.web_user_id "
                    + "ORDER BY post_id; ";
            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
            ResultSet results = stmt.executeQuery();
            while (results.next()) {
                sdl.add(results);
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            StringData sd = new StringData();
            sd.errorMsg = "Exception thrown in UserPostView.userPostAPI(): " + e.getMessage();
            sdl.add(sd);
        }

        return sdl;
    }

}
