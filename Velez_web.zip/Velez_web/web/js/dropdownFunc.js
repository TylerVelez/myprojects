//code used from sample code 07 provided by Instructor 
"use strict"; 

function dropdownFunc (dropHeaderStyle, dropContentStyle, hiddenRight ) {
    var headerList = document.getElementsByClassName(dropHeaderStyle);
    for (var i = 0; i < headerList.length; i++) {
        headerList[i].onclick = function () {
          var parent = this.parentElement; 
          var dContent = parent.getElementsByClassName(dropContentStyle)[0];//there is only one drop content in our container
          var dropContentList = document.getElementsByClassName(dropContentStyle);
        
          for (var i = 0; i < dropContentList.length; i++) {
                if (dropContentList[i] !== dContent) {
                    hide(dropContentList[i]);
                }
            }
            
       if (dContent.style.visibility === "visible") {
                hide(dContent);
            } else {
                show(dContent);
            }

        };
    }


    // private function, makes element invisible (display:none cannot be used with transition/amimation).
    // By setting the right attribute to large negative number, the element will be placed far off screen
    // to the right and this will be where it starts when it is next made visible (for the "zoom in from 
    // right" animation). 
    function hide(ele) {
        ele.style.right = hiddenRight;
        ele.style.visibility = "hidden";
    }

    // private function, makes element visible.
    function show(ele) {
        ele.style.visibility = "visible";
        ele.style.right = "0px";
    }

    // private function, makes all drop content elements hidden.
    function hideAllDropContents() {
        var dropContentList = document.getElementsByClassName(dropContentStyle);
        for (var i = 0; i < dropContentList.length; i++) {
            hide(dropContentList[i]);
        }
    }

    // Make it so that all dropdown content elements close whenever the user clicks anywhere 
    // but on a drop down header.
    window.onclick = function (event) {
        if (!event.target.matches('.' + dropHeaderStyle)) {
            hideAllDropContents();
            //console.log("hiding all drop contents");
        } else {
            //console.log("not hiding all drop contents");
        }
    };

}

