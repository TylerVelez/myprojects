function ajax (params){
    
    if (!params || !params.url || !params.successFn || !params.errorId) {
        alert ("function ajax requires an input parameter object with properties: url, successFn, and errorId");
        return;
    }

    var httpReq;
    if (window.XMLHttpRequest) {
        httpReq = new XMLHttpRequest(); 
    } else if (window.ActiveXObject) {
        httpReq = new ActiveXObject("Microsoft.XMLHTTP");
    } else {
        alert('ajax not supported');
    }

    httpReq.open("GET", params.url);
    
    httpReq.onreadystatechange = function () {

    
        if (httpReq.readyState === 4) {
            if (httpReq.status === 200) {
                var obj = JSON.parse(httpReq.responseText);
                params.successFn(obj);  
            } else {
                document.getElementById(params.errorId).innerHTML = "Error (" + httpReq.status + " " + httpReq.statusText +
                        ") while attempting to read '" + params.url + "'";
            }
        }
    }; 

    httpReq.send(null); 

} 


