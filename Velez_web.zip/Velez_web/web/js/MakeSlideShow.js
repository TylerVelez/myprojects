function MakeSlideShow(params) {




    // if (!params || !params.ssID || !document.getElementById(params.ssID) ||
    //          !params.objList || !params.objList[0] || !params.picPropName || !params.captionName )
    //  {
    //      alert("MakeSlideShow requires a parameter object with these properties:\n" +
    //              "   ssID:            id in which to render slideshow,\n" +
    //            "   objList:         array of objects that each have pic file name and caption, \n" +
    //              "   picPropName:     name of property (in objects) that holds image file name, \n)");
    //      return;
    //  }

    var ssID = params.ssID || "content";
    var slideShow = document.getElementById(ssID);
    var objList = params.objList || "";
    var picPropName = params.picPropName || "picture";
    var captionName = params.captionName || "captionName";
    var setLinks = 1;
    var linkAddress = ""; 
    if (params.optionalCap) {
        var caption2 = params.optionalCap;
    }


    // add a div that will hold the image
    var div = document.createElement("div");
    slideShow.appendChild(div);

    // add image into the div & set the image's src attribute to the 1st picture in the list
    var myImage = document.createElement("img");
    div.append(myImage);

    var div2 = document.createElement("div");
    slideShow.append(div2);

    var caption = document.createElement("p");
    div2.append(caption);

    // add back button under the image (and space between buttons)
    var backButton = document.createElement("button");
    backButton.innerHTML = " &lt; "; // HTML code for the less than sign.
    slideShow.appendChild(backButton);

    // add forward button after back button and space
    var fwdButton = document.createElement("button");
    fwdButton.innerHTML = " &gt; "; // HTML code for the greater than sign.
    slideShow.appendChild(fwdButton);

    // Private variable that keeps track of which image is showing
    var picNum = 0;
    if(setLinks === 2){
        updatePic2(linkAddress);
        } else{
        updatePic();
    }

    // Private method to advance to next image in the picture list
    function nextPic() {
        picNum++;
        if (picNum >= objList.length) {
            picNum = 0;
        }
        // change the src attribute of the image element to the desired new image)
        if(setLinks === 2){
            updatePic2(linkAddress);
        } else{
        updatePic();
    }
    }

    // Private method to go back to the previous image in the picture list
    function prevPic() {
        picNum--;
        if (picNum < 0) {
            picNum = objList.length - 1;
        }
        // change the src attribute of the image element to the desired new image)				
          if(setLinks === 2){
            updatePic2(linkAddress);
        } else{
        updatePic();
    }
    }

    // Whenever anyone clicks the back button, make the prevPic method run
    // Whenever anyone clicks the fwd button, make the nextPic method run
    backButton.onclick = prevPic;
    fwdButton.onclick = nextPic;

    // Example of a public method that the HTML coder can invoke when/if they want to 
    slideShow.setPicNum = function (newNum) {
        if ((newNum >= 0) && (newNum < objList.length)) {
            picNum = newNum;
            // change the src attribute of the image element to the desired new image)				
        if(setLinks === 2){
            updatePic2(linkAddress);
        } else{
        updatePic();
    }
        }
    };

    //this function makes every single captiona link to the corresponding HTML table related to its API
    slideShow.activateCaptions = function (hashAddress) {
          linkAddress = hashAddress; 
          setLinks = 2; 
          updatePic2(linkAddress);
    };
    function updatePic2(address) {
        var obj = objList[picNum];
        myImage.src = obj[picPropName];
        if (caption2) {
    
            caption.innerHTML = "<a href=" + address + "\>" + obj[captionName] + ": " + obj[caption2] + "</a>";
        } else {
            caption.innerHTML = "<a href=" + address + "\>" + obj[captionName] + "</a>";
        }
    }





    function updatePic() {
        var obj = objList[picNum];
        myImage.src = obj[picPropName];
        if (caption2) {
            caption.innerHTML = obj[captionName] + ": " + obj[caption2];
        } else {
            caption.innerHTML = obj[captionName];
        }
    }

    return slideShow;
}



