var userCRUD =  {};

userCRUD.delete = "pics/delete.png";
userCRUD.insert = "pics/insert.png";
userCRUD.update = "pics/update.png";



