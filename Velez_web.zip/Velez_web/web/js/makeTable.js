function makeTable (sortIcon) {

    var tableBuilder = {}; 

    tableBuilder.build = function (params) {

      
        function prettyColumnHeading(propName) {

            if (propName.length === 0) {
                return "";
            }

            var newHdg = "<img src='" + sortIcon + "'>";
            newHdg += " ";
            
            newHdg += propName.charAt(0).toUpperCase();
           
            for (var i = 1; i < propName.length; i++) {
                if (propName.charAt(i) < "a") {
                    newHdg += " ";
                }
                newHdg += propName.charAt(i);
            }
            return newHdg;
        } 


        
        function align(tableData,width) {
            console.log("width is" + width);
            var cellContent = tableData.innerHTML;
            if (cellContent.includes("jpg") || cellContent.includes("png") || cellContent.includes("http") || cellContent.includes("data") ) {
                if(!cellContent.includes("delete icon")){
                tableData.innerHTML = "<img width='" + width + "' src='" + cellContent + "'>";
                tableData.style.textAlign = "center";
            }
            
        }
            
            if (!isNaN(cellContent) || 
                    ((cellContent.length > 0) && (cellContent.charAt(0) === "$"))) { 
                tableData.style.textAlign = "right";
            
            }
        } 
        
        function buildColHeadings(newTable, list) {

            
            var tableHead = document.createElement("thead");
            newTable.appendChild(tableHead);
            var tableHeadRow = document.createElement("tr");
            tableHead.appendChild(tableHeadRow);

       
            var data = list[0];
            for (var prop in data) {
                var tableHeadDetail = document.createElement("th");
                tableHeadRow.appendChild(tableHeadDetail);
                tableHeadDetail.innerHTML = prettyColumnHeading(prop);
                tableHeadDetail.sortOrder = prop; 
                tableHeadDetail.sortReverse = false; 

                tableHeadDetail.onclick = function () {
                  
                    console.log("SORTING by " + this.sortOrder + " -  this.sortReverse is " + this.sortReverse);
                    tableBuilder.sort(list, this.sortOrder, this.sortReverse);
                    fillRows(newTable, list);
                    this.sortReverse = !this.sortReverse;
                    console.log("SORTed sortReverse is now " + this.sortReverse);
                };
            }
        } 


        
        function isToShow(obj, searchKey) {
            if (!searchKey || searchKey.length === 0) {
                return true; 
            }
            var searchKeyUpper = searchKey.toUpperCase();
            for (var prop in obj) {
                var propVal = obj[prop]; 
                console.log("checking if " + searchKeyUpper + " is in " + propVal);
                var propValUpper = propVal.toUpperCase();
                if (propValUpper.includes(searchKeyUpper)) {
                    console.log("yes it is inside");
                    return true;
                }
            }
            console.log("no it is not inside");
            return false;
        }
     
        function fillRows(newTable, list, searchValue) {
            
            var oldBody = newTable.getElementsByTagName("tbody");
            if (oldBody[0]) {
                console.log("ready to remove oldBody");
                newTable.removeChild(oldBody[0]);
            }

          
            var tableBody = document.createElement("tbody");
            newTable.appendChild(tableBody);

            for (var i in list) {
                var data = list[i];
                if (isToShow(data, searchValue)) {

                    var tableRow = document.createElement("tr");
                    tableBody.appendChild(tableRow);

                    // "prop" iterates over the properties in object "data"
                    for (var prop in data) {
                        var tableData = document.createElement("td");
                        tableRow.appendChild(tableData);
                        tableData.innerHTML = data[prop];
                        if(imgWidth[0].imgCol1 === prop){
                            console.log("here");
                            var width = imgWidth[0].imgWidth1;
                        }
                        else if(imgWidth[1].imgCol2 === prop){
                            console.log("here2");
                            var width = imgWidth[1].imgWidth2;
                        }
                        
                        align(tableData,width);
                    }
                } 
            }
        } 



        if (!params || !params.list || params.list.length < 1) {
            alert("Must supply input parameter object with 'list' property that holds an array with at least one element.");
            return;
        }
        var list = params.list;
        var target = params.target;
        if (!params.target) {
            alert("Must supply input parameter object with 'target' property " +
                    "that references a valid DOM object (where HTML table is to be placed).");
            return;
        }

        var orderPropName = params.orderPropName || ""; 

        var reverse = params.reverse || false; 

        var style = params.style || "dataList";
        target.classList.add(style);

        var imgWidth = params.imgWidths || "100px"; 
        
        if (orderPropName && orderPropName.length > 0) {
            tableBuilder.sort(list, orderPropName, reverse);
            console.log("SORTED LIST NEXT LINE");
            console.log(list);
        }

    
        var newTable = document.createElement("table");

        if (params.searchKeyElem) {
            console.log("there is a search key textbox");
            params.searchKeyElem.onkeyup = function () {
                console.log("search key is " + params.searchKeyElem.value);
                fillRows(newTable, list, params.searchKeyElem.value);
            };
        }

        target.innerHTML = ""; 
        target.appendChild(newTable);

        buildColHeadings(newTable, list);
        fillRows(newTable, list, ""); 

    }; 


// function tableBuilder.convert: takes a string, returns proper type (e.g., date, number etc). 

// If the String value in the cell being sorted contains a Date, convert to date type and return that. 
// If the String value contains a number, convert to number and return that (but after removing 
// commas and dollar signs that may be part of formatted numeric values).
// Else return the capitalized version of the String value that came in. 
    tableBuilder.convert = function (s) {

        if (!s || s.length === 0) {
            //console.log("s is null or empty string");
            return -1;
        }

        // a string that holds a date returns true for isNaN(strDate) (it's not a number)  
        // And it returns false for isNaN(Date.parse(strDate))
        var parsedDate = Date.parse(s);
        if (isNaN(s) && !isNaN(parsedDate)) {
            //console.log(s + " is a Date ");
            return parsedDate;
        } else {
            var tmp = s;
            console.log("tmp is " + tmp);
            tmp = tmp.replace("$", ""); // remove dollar signs
            tmp = tmp.replace(",", ""); // remove commas
            if (isNaN(tmp)) { // if not a number, return what was passed in 
                //console.log(s + " is a string - convert to uppercase for sorting purposes");
                return s.toUpperCase();
            } else {
                //console.log(tmp + " is a number");
                return Number(tmp);
            }
        }
    }; // convert 


// compare the value a to b and return 1 (if a>b), or 0 (if values equal), or -1 otherwise.
// a and b are strings coming in. Convert them to their proper type before comparing. 
    tableBuilder.compare = function (a, b, reverse) {

        // convert each 
        var aConverted = tableBuilder.convert(a);
        var bConverted = tableBuilder.convert(b);

        // dates and numbers sort best when null/empty values are represented as -1 (which is what convert already does)
        // but strings/images sort best when null/empty string are represented as "" (empty string)
        if (aConverted === -1 && isNaN(bConverted)) {
            aConverted = "";
            //console.log("1st value was -1 and 2nd was string, changed -1 to empty");
        }
        if (bConverted === -1 && isNaN(aConverted)) {
            bConverted = "";
            //console.log("2nd value was -1 and 1nd was string, changed -1 to empty");
        }

        // come up with comparison value: 1, 0, or -1
        var comparison = 0;
        if (aConverted > bConverted) {
            comparison = 1;
        } else if (aConverted < bConverted) {
            comparison = -1;
        }
        console.log("comparing " + aConverted + " to " + bConverted + " is " + comparison);
        if (reverse) {
            comparison = -comparison;
        }
        return comparison;
    }; // compare 

    tableBuilder.sort = function (list, byProperty, reverse) {

       

       
        list.sort(function (q, r) {

            return tableBuilder.compare(q[byProperty], r[byProperty], reverse);
        });
    }; // sort
    
    return tableBuilder;
}