var posts = {};

posts.list = function(targetId) {

   
    var contentDOM = document.getElementById(targetId);
    contentDOM.innerHTML = "";

    ajax({
        url: "webAPIs/listOtherAPI.jsp",
        successFn: success,
        errorId: targetId
    });

    function success(obj) {

        if (!obj) {
            contentDOM.innerHTML += "Http Request (from AJAX call) did not parse to an object.";
            return;
        }
        console.log(obj);

        if (obj.dbError.length > 0) {
            contentDOM.innerHTML += "Database Error Encountered: " + obj.dbError;
            return;
        }

        var div = document.createElement("div");
        div.style.textAlign = "center";
        contentDOM.appendChild(div);
        var img = userCRUD.insert;
        div.innerHTML = "<h2>Skateboarding Posts <a href= '#/inserttwo'><img src='" + img +"'/></a></h2>SearchFilter:";

        var searchBox = document.createElement("input");
        searchBox.setAttribute("type", "text");
        div.appendChild(searchBox);

        var tableDiv = document.createElement("div");
        contentDOM.appendChild(tableDiv);

        var dImg = userCRUD.delete;
        var userList = [];
        for (var i = 0; i < obj.userPost.length; i++) {
            userList[i] = {}; // add new empty object to array
            userList[i].postName = obj.userPost[i].postName; 
            userList[i].postInformation = "Location: " + obj.userPost[i].location + "<br>"+
            "Years Skating: " + obj.userPost[i].yearsSkating + "<br>"+
            "Minutes Shooting Trick: " + obj.userPost[i].minutesShootingTrick + "<br>"+
            "Description: " + obj.userPost[i].description;
            userList[i].skatePicture = obj.userPost[i].imageURL;
            userList[i].userCredentials = obj.userPost[i].userEmail + "<br/> PW (to test Logon): " +
                    obj.userPost[i].userPassword;
            userList[i].skatePicture = obj.userPost[i].imageURL;
            userList[i].image = obj.userPost[i].image;
            userList[i].birthday = obj.userPost[i].birthday;
            userList[i].membershipFee = obj.userPost[i].membershipFee;
            userList[i].IdInfo = "Role: " +obj.userPost[i].userRoleId+ "<br>"+
            "User: " + obj.userPost[i].webUserID + "<br>"+
            "Post :" + obj.userPost[i].postID;
            userList[i].delete = "<img src='" + dImg + "' alt='delete icon' onclick='posts.delete(" +
                    obj.userPost[i].postID + ",this,"+targetId+")'/>";

        }

        tableBuilder.build({
            list: userList,
            target: tableDiv,
            style: "data",
            orderPropName: "userEmail",
            searchKeyElem: searchBox,
            reverse: false,
            imgWidths: [{imgCol1: "skatePicture", imgWidth1: "250px"},{imgCol2: "image", imgWidth2: "50px"}]
        });
    } 

}; 
posts.delete = function (postId, icon,targetId) {
    if (confirm("Do you really want to delete user " + postId + "? ")) {
    
    var aURL = "webAPIs/deleteOtherAPI.jsp?deleteId=" + postId;      
        ajax({
        url: aURL,
        successFn: success,
        errorId: targetId
    });
function success(obj){
        if (obj.errorMsg.length > 0){
        alert("Failed to delete record: " + obj.errorMsg); 
        } else{
        var dataRow = icon.parentNode.parentNode; //cell that was clicked
        var rowIndex = dataRow.rowIndex - 1; // adjust for oolumn header row?
        var dataTable = dataRow.parentNode; //row that was click
        dataTable.deleteRow(rowIndex);//built in function to delete row of html table    
        } 
}     
}
};


posts.find = function(targetId) {
    
};
posts.insertUI = function (targetId){
    var contentDOM = document.getElementById(targetId);
    contentDOM.style.textAlign ="center"; 
    contentDOM.innerHTML = "";
    ajax({
        url: "webAPIs/getProfileAPI.jsp",
       successFn: success,
        errorId: targetId
    });
    function success(obj){
       // if (!obj.webUserList[0].webUserId){
       // contentDOM.innerHTML = "You must be signed in to make a post.";
      //  return;
        if (obj.dbError.length > 0) {
        contentDOM.innerHTML = "Database Error Encountered: " + obj.dbError;
        return; 
        }
         var webID = obj.webUserList[0].webUserId;
         if(!webID){
             webID = 999999999; 
         }
         var html = `
    <div id="insertArea">
        <br/>
        <table>
            <tr>
                <td>Post Name</td>
                <td><input type="text"  id="postName" /></td>
                <td id="postNameError" class="error"></td> 
            </tr>
            <tr>
                <td>Image URL</td>
                <td><input type="text"  id="imageURL" /></td>
                <td id="imageURLErrror" class="error"></td>
            </tr>
            <tr>
                <td>Description</td>
                <td><input type="text" id="description" /></td>
                <td id="descriptionError" class="error"></td>
            </tr>
            <tr>
                <td>Years Skating</td>
                <td><input type="text" id="yearsSkating" /></td>
                <td id="yearsSkatingError" class="error"></td> 
            </tr>
            <tr>
                <td>Location</td>
                <td><input type="text" id="location" /></td>
                <td id="locationError" class="error"></td>
            </tr>
            <tr>
                <td>Minutes Shooting Trick</td>
                <td><input type="text" id="minutesShootingTrick" /></td>
                <td id="minutesShootingTrickError" class="error"></td>
            </tr>   
            `;
            html +=  "<tr> <td><button onclick='posts.insertSave(" + webID +")'>Save</button></td>"+
                "<td id='recordError' class='error'></td>"+
                "<td></td>"+
            "</tr>"+
        "</table>"+
    "</div>";
   
    contentDOM.innerHTML = html;
    
}    
        
        
};
 function writeErrorObjToUI(jsonObj) {
        console.log("here is JSON object (holds error messages.");
        console.log(jsonObj);

        document.getElementById("postNameError").innerHTML = jsonObj.postName;
        document.getElementById("imageURLErrror").innerHTML = jsonObj.imageURL;
        document.getElementById("descriptionError").innerHTML = jsonObj.description;
        document.getElementById("locationError").innerHTML = jsonObj.location;
        document.getElementById("minutesShootingTrickError").innerHTML = jsonObj.minutesShootingTrick;
        document.getElementById("recordError").innerHTML = jsonObj.errorMsg;
    }

function getUserDataFromUI(webUserID) {

        var userInputObj = {

            "postName": document.getElementById("postName").value,
            "imageURL": document.getElementById("imageURL").value,
            "description": document.getElementById("description").value,
            "location": document.getElementById("location").value,
            "minutesShootingTrick": document.getElementById("minutesShootingTrick").value,
            "webUserID": webUserID,
            "errorMsg": ""
        };

        console.log(userInputObj);

        // JSON.stringify converts the javaScript object into JSON format 
        // (the reverse operation of what gson does on the server side).
        // 
        // Then, you have to encode the user's data (encodes special characters 
        // like space to %20 so the server will accept it with no security error. 
        return encodeURIComponent(JSON.stringify(userInputObj));
        //return escape(JSON.stringify(userInputObj));
    }

posts.insertSave = function (webUserID) {

        console.log("users.insertSave was called --- " + webUserID);

        // create a user object from the values that the user has typed into the page.
        var myData = getUserDataFromUI(webUserID);

        ajax({
            url: "webAPIs/insertOtherAPI.jsp?jsonData=" + myData,
            successFn: processInsert,
            errorId: "recordError"
        });

        function processInsert(jsonObj) {
            console.log(jsonObj);
            if (jsonObj.errorMsg.length === 0) { // success
                jsonObj.errorMsg = "Record successfully inserted !!!";
            } 

            writeErrorObjToUI(jsonObj);
        }
    };
