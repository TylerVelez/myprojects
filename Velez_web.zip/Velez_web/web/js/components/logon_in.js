var logon = {};

logon.UI = function (id) {
 var content = ` 
 <div class='logon'>
 <br/>
 Email Address <input type="text" value="" id="logonEmailAddress"/>
 &nbsp;
 Password <input type="password" value="" id="logonPassword"/>
 &nbsp;
 <input type="button" value="Submit" onclick="logon.findUser('logonEmailAddress','logonPassword','msgArea')"/>
 <br/> <br/>
 <div id="msgArea"></div>
 </div>
 `; // closing back tick
 document.getElementById(id).innerHTML = content;
};
logon.findUser = function (emailId, pwId, msgId) {
    contentDOM = document.getElementById(msgId); 
    contentDOM.style.textAlign ="center"; 
    contentDOM.innerHTML = ""; 
    var userEmail = escape(document.getElementById(emailId).value);
    var userPassword = escape(document.getElementById(pwId).value); 
    console.log(userEmail + "-" + userPassword);
    var urlAPI = "webAPIs/logonAPI.jsp?email=" +userEmail+"&"+"password="+userPassword;  
    
      ajax({
        url: urlAPI ,
        successFn: success,
        errorId: msgId
    });
 function success(obj){
        console.log(obj); 
        if (!obj) {
        contentDOM.innerHTML = "Http Request (from AJAX call) did not parse to an object.";
        return;
        }
        if (obj.dbError.length > 0) {
        contentDOM.innerHTML = "Database Error Encountered: " + obj.dbError;
        return; 
        }
        if (obj.webUserList[0].webUserId.length === 0){
        contentDOM.innerHTML = "User Id  or Password not found.";
        return;
        }
     
        
        var webID = obj.webUserList[0].webUserId;
        var bDay = obj.webUserList[0].birthday;
        var membership = obj.webUserList[0].membershipFee;
        var role = obj.webUserList[0].userRoleId + " " + obj.webUserList[0].userRoleType;
        var image = obj.webUserList[0].image; 
        contentDOM.innerHTML = "Welcome Web User: " + webID + "<br>"+
                         "Birthday: " + bDay +"<br>"+
                         "Membership Fee: " + membership + "<br>"+
                         "<img src='" + image + "'>";

    } 
    
};

