"use strict";

var slideshow = {};

slideshow.display = function (targetID) {

    var contentDOM = document.getElementById(targetID);
    contentDOM.innerHTML = "";

    var innerH = `<div class = "row2">
            <div class = "column column50">
            <div class = "picContainer" id = "slideshow"> </div>
            </div>
            <div class = "column column50" >
            <div class = "picContainer" id = "slideshow1"> </div>
            </div>
            </div>`;



            contentDOM.innerHTML = innerH;


    ajax({url: "webAPIs/listUsersAPI.jsp", successFn: success, errorId: "slideId"});

    function success(obj) {
        console.log(obj.webUserList);

        var ss = MakeSlideShow({
            ssID: "slideshow", // id in which to render slideshow,
            objList: obj.webUserList, // array of objects with image and caption
            picPropName: "image",
            captionName: "userEmail",
            optionalCap: "userRoleType" //OPTIONAL: set your own custom caption
                    //from the set of options in the WebUserList

        });
        //this function makes every single captiona link to the corresponding HTML table related to its API
        ss.activateCaptions("#/skaters");

    }


    ajax({url: "webAPIs/listOtherAPI.jsp", successFn: success2, errorId: "slideId"});

    function success2(obj) {
        console.log(obj);

        var ss = MakeSlideShow({
            ssID: "slideshow1", // id in which to render slideshow,
            objList: obj.userPost, // array of objects with image and caption
            picPropName: "imageURL",
            captionName: "postName",
            optionalCap: "location" //OPTIONAL: set your own custom caption 
                    //from the set of options in the User Post object
        });
        //this function makes every single captiona link to the corresponding HTML table related to its API
        ss.activateCaptions("#/posts");

    }




};

slideshow.find = function (targetId) {

};




