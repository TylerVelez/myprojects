var skaters = {};

(function () {
skaters.list = function(targetId) {

    var contentDOM = document.getElementById(targetId);
    contentDOM.innerHTML = "";

    ajax({
        url: "webAPIs/listUsersAPI.jsp",
        successFn: success,
        errorId: targetId
    });

    function success(obj) {

        if (!obj) {
            contentDOM.innerHTML += "Http Request (from AJAX call) did not parse to an object.";
            return;
        }
        console.log(obj);

        if (obj.dbError.length > 0) {
            contentDOM.innerHTML += "Database Error Encountered: " + obj.dbError;
            return;
        }

        var div = document.createElement("div");
        div.style.textAlign = "center";
        contentDOM.appendChild(div);
        var img = userCRUD.insert; 
        div.innerHTML = "<h2>Skateboarders <a href= '#/insert'><img src='" + img +"'/></a></h2>SearchFilter:"; 


        var searchBox = document.createElement("input");
        searchBox.setAttribute("type", "text");
        div.appendChild(searchBox);

        var tableDiv = document.createElement("div");
        contentDOM.appendChild(tableDiv);
        var dImg = userCRUD.delete;
        var userList = [];
        for (var i = 0; i < obj.webUserList.length; i++) {
            userList[i] = {}; 
            userList[i].userCredentials = obj.webUserList[i].userEmail + "<br/> PW (to test Logon): " +
                    obj.webUserList[i].userPassword;
            userList[i].image = obj.webUserList[i].image;
            userList[i].birthday = obj.webUserList[i].birthday;
            userList[i].membershipFee = obj.webUserList[i].membershipFee;
            userList[i].role = obj.webUserList[i].userRoleId + "&nbsp;" +
                    obj.webUserList[i].userRoleType;
            userList[i].userId = obj.webUserList[i].webUserId;
            userList[i].delete = "<img src='" + dImg + "' alt='delete icon' onclick='skaters.delete(" +
                    userList[i].userId + ",this,"+targetId+")'/>";

        }

        tableBuilder.build({
            list: userList,
            target: tableDiv,
            style: "data",
            orderPropName: "userEmail",
            searchKeyElem: searchBox,
            reverse: false,
            imgWidths: [{imgCol1: "skatePicture", imgWidth1: "250px"},{imgCol2: "image", imgWidth2: "50px"}]
        });
    } 

}; 

skaters.find = function(targetId) {
    
};
skaters.getProfile = function(targetId){
    var contentDOM = document.getElementById(targetId);
    contentDOM.style.textAlign ="center"; 
    contentDOM.innerHTML = "";
     ajax({
        url: "webAPIs/getProfileAPI.jsp",
        successFn: success,
        errorId: targetId
    });
    function success(obj){
        if (!obj) {
        contentDOM.innerHTML = "Http Request (from AJAX call) did not parse to an object.";
        return;
        }
        if (obj.webUserList.length === 0 ){
        contentDOM.innerHTML = "You are not logged in.";
        return;
        }
        if (obj.dbError.length > 0) {
        contentDOM.innerHTML = "Database Error Encountered: " + obj.dbError;
        return; 
        }
        if(obj.webUserList[0].errorMsg.length > 0){
        contentDOM.innerHTML = obj.webUserList[0].errorMsg;
        return; 
        }
        var webID = obj.webUserList[0].webUserId;
        var bDay = obj.webUserList[0].birthday;
        var membership = obj.webUserList[0].membershipFee;
        var role = obj.webUserList[0].userRoleId + " " + obj.webUserList[0].userRoleType;
        var image = obj.webUserList[0].image; 
        contentDOM.innerHTML = "Welcome Web User: " + webID + "<br>"+
                         "Birthday: " + bDay +"<br>"+
                         "Membership Fee: " + membership + "<br>"+
                         "<img src='" + image + "'>";
    }
    
    
};
skaters.logout = function(targetId){
    var contentDOM = document.getElementById(targetId);
    contentDOM.style.textAlign ="center"; 
    contentDOM.innerHTML = "";
     ajax({
        url: "webAPIs/logoutAPI.jsp",
        successFn: success,
        errorId: targetId
    });
    function success(obj){
        if(obj.dbError.length > 0){ //I used dbError as a way to provide the user with feedback about logging out
            contentDOM.innerHTML = "You have logged out.";
        } else {
            contentDOM.innerHTML = "You where not logged in.";
        }
    }
    
};
skaters.delete = function (userId, icon,targetId) {
    if (confirm("Do you really want to delete user " + userId + "? ")) {
    
    var aURL = "webAPIs/deleteUserAPI.jsp?deleteId=" + userId;      
        ajax({
        url: aURL,
        successFn: success,
        errorId: targetId
    });
function success(obj){
        if (obj.errorMsg.length > 0){
        alert("Failed to delete record: " + obj.errorMsg); 
        } else{
        var dataRow = icon.parentNode.parentNode; //cell that was clicked
        var rowIndex = dataRow.rowIndex - 1; // adjust for oolumn header row?
        var dataTable = dataRow.parentNode; //row that was click
        dataTable.deleteRow(rowIndex);//built in function to delete row of html table    
        } 
}     
}
};
 skaters.insertUI = function (targetId){
    console.log("users.inusertUI function - targetId is " + targetId);

    var html = `
    <div id="insertArea">
        <br/>
        <table>
            <tr>
                <td>Email Address</td>
                <td><input type="text"  id="userEmail" /></td>
                <td id="userEmailError" class="error"></td> 
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password"  id="userPassword" /></td>
                <td id="userPasswordError" class="error"></td>
            </tr>
            <tr>
                <td>Retype Your Password</td>
                <td><input type="password" id="userPassword2" /></td>
                <td id="userPassword2Error" class="error"></td>
            </tr>
            <tr>
                <td>Birthday</td>
                <td><input type="text" id="birthday" /></td>
                <td id="birthdayError" class="error"></td> 
            </tr>
            <tr>
                <td>Membership Fee</td>
                <td><input type="text" id="membershipFee" /></td>
                <td id="membershipFeeError" class="error"></td>
            </tr>
            <tr>
                <td>User Role</td>
                <td>
                    <select id="rolePickList">
                    <!-- JS code will make ajax call to get all the roles 
                    then populate this select tag's options with those roles -->
                    </select>
                </td>
                <td id="userRoleIdError" class="error"></td>
            </tr>
            <tr>
                <!-- see js/insertUser.js to see the insertUser function (make sure index.html references the js file) -->
                <td><button onclick="skaters.insertSave()">Save</button></td>
                <td id="recordError" class="error"></td>
                <td></td>
            </tr>
        </table>
    </div>
    `;
        document.getElementById(targetId).innerHTML = html;

        ajax({
            url: "webAPIs/getRolesAPI.jsp",
            successFn: setRolePickList,
            errorId: "userRoleIdError"
        });

        function setRolePickList(jsonObj) {

            console.log("setRolePickList was called, see next line for object holding list of roles");
            console.log(jsonObj);

            if (jsonObj.dbError.length > 0) {
                document.getElementById("userRoleIdError").innerHTML = jsonObj.dbError;
                return;
            }

            Utils.makePickList({
                id: "rolePickList",
                list: jsonObj.roleList,
                valueProp: "userRoleType",
                keyProp: "userRoleId"
            });

        }
 };
    // a private function
    function getUserDataFromUI() {

        // New code for handling role pick list.
        var ddList = document.getElementById("rolePickList");

        // create a user object from the values that the user has typed into the page.
        var userInputObj = {

            "userEmail": document.getElementById("userEmail").value,
            "userPassword": document.getElementById("userPassword").value,
            "userPassword2": document.getElementById("userPassword2").value,
            "birthday": document.getElementById("birthday").value,
            "membershipFee": document.getElementById("membershipFee").value,

            // Modification here for role pick list
            //"userRoleId": document.getElementById("userRoleId").value,
            "userRoleId": ddList.options[ddList.selectedIndex].value,

            "userRoleType": "",
            "errorMsg": ""
        };

        console.log(userInputObj);

        // JSON.stringify converts the javaScript object into JSON format 
        // (the reverse operation of what gson does on the server side).
        // 
        // Then, you have to encode the user's data (encodes special characters 
        // like space to %20 so the server will accept it with no security error. 
        return encodeURIComponent(JSON.stringify(userInputObj));
        //return escape(JSON.stringify(userInputObj));
    }

    function writeErrorObjToUI(jsonObj) {
        console.log("here is JSON object (holds error messages.");
        console.log(jsonObj);

        document.getElementById("userEmailError").innerHTML = jsonObj.userEmail;
        document.getElementById("userPasswordError").innerHTML = jsonObj.userPassword;
        document.getElementById("userPassword2Error").innerHTML = jsonObj.userPassword2;
        document.getElementById("birthdayError").innerHTML = jsonObj.birthday;
        document.getElementById("membershipFeeError").innerHTML = jsonObj.membershipFee;
        document.getElementById("userRoleIdError").innerHTML = jsonObj.userRoleId;
        document.getElementById("recordError").innerHTML = jsonObj.errorMsg;
    }

    skaters.insertSave = function () {

        console.log("users.insertSave was called");

        // create a user object from the values that the user has typed into the page.
        var myData = getUserDataFromUI();

        ajax({
            url: "webAPIs/insertUserAPI.jsp?jsonData=" + myData,
            successFn: processInsert,
            errorId: "recordError"
        });

        function processInsert(jsonObj) {

            // the server prints out a JSON string of an object that holds field level error 
            // messages. The error message object (conveniently) has its fiels named exactly 
            // the same as the input data was named. 

            if (jsonObj.errorMsg.length === 0) { // success
                jsonObj.errorMsg = "Record successfully inserted !!!";
            }

            writeErrorObjToUI(jsonObj);
        }
    };

}());