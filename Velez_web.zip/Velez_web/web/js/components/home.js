function home(contentID) {
    var content = 
            "<div class = \"post\">" +
            "<h1>Be a part of the greatest collection of skate photos in History!</h1>" +
            "<p>" +
            "Skateboarding is beautiful and deserves to be shared with the world. It does not matter" +
            " if you are a 10 year pro or are just beginning your skate journey. Skate Hubba is the ultimate " +
            "platform for your action shots. Here you can see what skaters around the world are doing and " +
            "share your skating with the whole community!" +
            "</p>" +
            "</div>";
    document.getElementById(contentID).innerHTML = content; //get the view tag in the document and make the innner HMTL the content we just made
}

