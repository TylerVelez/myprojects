function blog(id) {
    var content = `
            <div class = "post"> 
            <h2>HW 1 Home Page</h2>
            <p>
            My web development experience consists of to programming courses in PHP thourgh the MIS program.
            </p>
            <p>
            In this homework I learned about HTML, CSS, and how to publish a web page.
            The parts that I found easy were figuring out responsive web design.
            The parts that I found hard or confusing were understanding the Javascript functions.
            </p>
            </div> 
            <div class = "post"> 
            <h2>HW 2 Routing &amp; DB</h2>
            <p>
            My database experience consists of advanced knowledge of ERD modeling, cardinality, and SQL queries.
            </p>
            <p>
            In this homework I learned the benifits of using single page web design.
            The parts that I found easy were breaking the pages into components.
            The parts that I found hard or confusing were understanding the Javascript in the routing function.
            </p>
            <ul>
            <li>
            To see how my routing works, click on these icons: home, then blog, then home again.
            </li>
            <li>
            To see my database work, click <a href="Velez_HW2_DB.docx">here</a>
            </li>
            </ul>
            </div>
            <div class = "post"> 
             <h2>HW 3 Web API</h2>
    <p>
        In this homework I learned how to write a web API using Java code.
        The parts that I found easy were writing the SQL statment and understanding the Java syntax.
        The parts that I found hard or confusing were tracing the Java classes I created if an error came up. 
    </p>
    <ul>
        <li>
            To invoke my user list Web API, click <a target="_blank" href="webAPIs/listUsersAPI.jsp">here</a>.
        </li>
        <li>
            To invoke my user post Web API, click <a target="_blank" href="webAPIs/listOtherAPI.jsp">here</a>.
        </li>
        <li>
            My error handling document can be found <a href="Velez_HW3_API_Error.docx">here</a>.
        </li>
    </ul>
    </div>
    <div class = "post"> 
        <h2>HW 4 Display Data</h2>
    <p>
        In this homework I learned how to use an AJAX request to read data from an API, and how to display that data in a well formatted table. 
        The parts that I found easy were understanding and implementing the AJAX call.
        The parts that I found hard or confusing were figuring out the intricacies of creating a well formatted reusable table and sorting JSON data. 
    </p>
    <ul>
        <li>
            To see my user and [other] list pages, click under the search icon 
            in the navigation bar. 
        </li>
    </ul>
    </div>
    <div class = "post"> 
      <h2>HW 5 JavaScript</h2>
    <p>
        In this homework I learned how to create slideshows using Javascript.
        The parts that I found easy were creating the Slideshows themselves. 
        The parts that I found hard or confusing were styling them and adding me public method. 
    </p>
     </div>
    <div class = "post">  
      <h2>HW 6 Log On</h2>
    <p>
        In this homework I learned how to use sessions so users can log on, view personal information, and log out.
        The parts that I found easy were most of the API writing and front end code. 
        The parts that I found hard or confusing were knowing under what partcular condition to set the session to make sure a user did not log on with no personal information. 
    </p>
    <ul>
        <li>
            To see how my Log On code works, click on these items under the 
            account icon: "Log On", "Profile", and "Log Off". You'll only see 
            the profile information if you are logged on.
        </li>
        <li>
         <a target="_blank" href="webAPIs/listUsersAPI.jsp">List All Users API</a>.<br>
         <a target="_blank" href="webAPIs/logonAPI.jsp?email=tuf97833@temple.edu&password=test1">Logon API</a>.<br>
         <a target="_blank" href="webAPIs/getProfileAPI.jsp">Get Profile API</a>.<br>
          <a target="_blank" href="webAPIs/logoutAPI.jsp">Log Out API (DB error is supposed to populate it is not an actual error see the code for detials)</a>.
        </li>
    </ul> 
    </div>
    <div class = "post"> 
      <h2>HW 7 Delete</h2>
    <p>
        In this homework I learned how to use a web API and user interface to delete records froma Database
        The parts that I found easy were writing the API on the server side 
        The parts that I found hard or confusing were adjusting the make table function to handle pictures and URLs as well as ready to go HTML coded pictures. 
    </p>
    <ul>
        <li>
            To see how delete user works, click on the delete icon next to a 
            user in my skaters listing (after clicking on "skaters" under the 
            search icon). 
        </li>
        <li>
            To see how delete posts works, click on the delete icon next to a 
            record in my posts listing.  
        </li>
    </ul>
    </div>
    <div class="post">
       <h2>HW 8 Insert</h2>
    <p>
        In this homework I learned how to write an Insert API and how to ingrate that API into client side code. 
        The parts that I found easy were writing the server side code for inserting and doing server side validation.
        The parts that I found hard or confusing were implementing the UI on the cleint side.  
    </p>
    <ul>
        <li>
            To see how insert user works, click on the plus sign at the top of the 
            user listing page -OR- click on the "register" item under the account icon to make your new account! 
        </li>
        <li>
            To see how inserting a Post works, click on the plus sign at the top of the 
            posts listing page. <b>You must be logged in to make a post!</b>
        </li>
    </ul>
    </div>`;
    document.getElementById(id).innerHTML = content;
}


